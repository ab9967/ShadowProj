my_list = [1,9,3,8,5,7]

for number in my_list:
    # Your code here
    print 2*number
