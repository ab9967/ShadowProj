
absolute = abs(-42)

print absolute
