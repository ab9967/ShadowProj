symbol_hash = {:anysymbol => 8,
    :pie => 3.14,
    :phi => 1.689
}
