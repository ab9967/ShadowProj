my_array = [[1,2],[3,4]]
