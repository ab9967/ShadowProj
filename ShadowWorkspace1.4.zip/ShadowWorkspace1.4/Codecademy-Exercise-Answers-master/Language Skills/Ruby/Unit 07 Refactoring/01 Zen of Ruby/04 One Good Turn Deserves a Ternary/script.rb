# Type your Ruby code below!
puts true ? "its true" : "its false"
