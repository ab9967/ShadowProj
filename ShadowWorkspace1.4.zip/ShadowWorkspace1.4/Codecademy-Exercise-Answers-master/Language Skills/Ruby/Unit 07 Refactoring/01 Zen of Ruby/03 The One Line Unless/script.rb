# Type your Ruby code below!
puts "Hi!" unless false
