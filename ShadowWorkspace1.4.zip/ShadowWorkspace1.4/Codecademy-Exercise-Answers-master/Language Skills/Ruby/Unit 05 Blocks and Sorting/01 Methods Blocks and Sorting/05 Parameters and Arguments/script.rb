def cubertino(n)
  puts n ** 3
end

cubertino(8)
