def welcome()
    puts "Welcome to Ruby!"
end

welcome()
