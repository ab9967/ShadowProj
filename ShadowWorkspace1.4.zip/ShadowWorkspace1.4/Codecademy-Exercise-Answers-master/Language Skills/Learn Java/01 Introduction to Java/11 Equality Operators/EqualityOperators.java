public class EqualityOperators {
	public static void main(String[] args) {

		System.out.println( 2 == 2 );

	}
}
