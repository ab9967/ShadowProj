class Dog {
  int age;
	public Dog(){

  }
	public static void main(String[] args) {

	}
}
