public class Variables {
	public static void main(String[] args) {

		int myNumber;
		boolean isFun;
		char movieRating;
		int myNumber = 42;
    boolean isFun = true;
    char movieRating = 'A';
	}
}
