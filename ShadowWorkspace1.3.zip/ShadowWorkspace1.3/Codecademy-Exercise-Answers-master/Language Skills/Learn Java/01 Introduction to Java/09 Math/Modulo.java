public class Modulo {
	public static void main(String[] args) {

		int myRemainder = 17 % 5;
		System.out.println(myRemainder);

	}
} 
