# Write your code below!
"L".upto("P") { |letter| puts letter }
