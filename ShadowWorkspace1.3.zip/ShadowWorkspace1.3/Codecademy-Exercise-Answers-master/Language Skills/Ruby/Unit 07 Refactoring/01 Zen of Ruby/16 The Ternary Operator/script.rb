puts 1 < 2 ? "One is less than two!" : "One is not less than two."
