string_array = ['aasd','fvsd','fvsad']
