for num in 1...10
  puts num
end