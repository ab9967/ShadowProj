my_array = [1, 2, 3, 4, 5]

my_array.each do |n|
    puts n**2
end
