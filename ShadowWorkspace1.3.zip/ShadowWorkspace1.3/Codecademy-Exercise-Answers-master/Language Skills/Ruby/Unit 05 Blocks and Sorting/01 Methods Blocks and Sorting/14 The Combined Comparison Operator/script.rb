book_1 = "A Wrinkle in Time"

book_2 = "A Brief History of Time"

book_1 <=> book_2
