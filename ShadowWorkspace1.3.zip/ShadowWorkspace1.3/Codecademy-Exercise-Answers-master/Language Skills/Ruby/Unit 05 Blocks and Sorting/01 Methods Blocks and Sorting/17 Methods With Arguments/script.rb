def welcome(name)
    return "Hello, #{name}"
end

welcome("User")
