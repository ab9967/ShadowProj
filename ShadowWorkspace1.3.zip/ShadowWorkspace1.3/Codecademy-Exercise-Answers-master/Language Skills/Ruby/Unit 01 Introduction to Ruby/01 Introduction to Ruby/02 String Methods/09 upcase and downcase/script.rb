puts "sassafras".upcase
puts "SASSAFRAS".downcase
