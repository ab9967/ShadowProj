# Ask Python to print sqrt(25) on line 3.
import math
print math.sqrt(25)
