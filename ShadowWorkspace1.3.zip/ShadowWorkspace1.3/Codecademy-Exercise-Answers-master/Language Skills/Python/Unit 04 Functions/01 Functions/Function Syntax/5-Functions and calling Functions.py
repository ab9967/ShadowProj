def one_good_turn(n):
    return n + 1

def deserves_another(n):
    return n + 3
