def list_function(x):
    return x[1]

n = [3, 5, 7]
print list_function(n)
