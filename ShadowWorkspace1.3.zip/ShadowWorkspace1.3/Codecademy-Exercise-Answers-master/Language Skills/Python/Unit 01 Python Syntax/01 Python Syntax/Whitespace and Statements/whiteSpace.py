def spam():
eggs = 12
return eggs

print spam()
