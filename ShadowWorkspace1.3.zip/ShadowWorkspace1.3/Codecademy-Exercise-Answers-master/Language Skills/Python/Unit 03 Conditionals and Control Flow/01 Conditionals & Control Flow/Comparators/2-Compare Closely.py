# Assign True or False as appropriate on the lines below!

# Set this to True if 17 < 328 or to False if it is not.
bool_one = True   # We did this one for you!

# Set this to True if 100 == (2 * 50) or to False otherwise

bool_two = 100 == (2*50)
print str(bool_two)

# Set this to True if 19 <= 19 or to False if it is not.
bool_three = 19 <= 19
print str(bool_three)

# Set this to True if -22 >= -18 or to False if it is not.
bool_four = -22 >= -18
print str(bool_four)

# Set this to True if 99 != (98 + 1) or to False otherwise.
bool_five = 99 != (98+1)
print str(bool_five)
