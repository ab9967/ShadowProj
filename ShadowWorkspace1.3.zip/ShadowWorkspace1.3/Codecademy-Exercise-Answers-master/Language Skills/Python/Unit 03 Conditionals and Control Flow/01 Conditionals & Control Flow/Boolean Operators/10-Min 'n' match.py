# Use boolean expressions as appropriate on the lines below!

# Make me false!
bool_one = (2 <= 2) and "Alpha" == "Bravo"  # We did this one for you!

# Make me true!
bool_two = (3 >= 1) or "Daniel" == "Dariana"

# Make me false!
bool_three = (234<= 33) and (True and False)

# Make me true!
bool_four = (32 > 23) and 'arthur' == 'arthur'

# Make me true!
bool_five = (54 != 33) or True
