"Sassafras".reverse
