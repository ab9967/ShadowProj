puts "string".object_id
puts "string".object_id

puts :symbol.object_id
puts :symbol.object_id
