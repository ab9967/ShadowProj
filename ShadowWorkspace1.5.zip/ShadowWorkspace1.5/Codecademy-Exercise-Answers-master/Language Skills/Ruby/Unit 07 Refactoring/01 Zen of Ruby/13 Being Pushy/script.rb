alphabet = ["a", "b", "c"]
alphabet << 'd' # Update me!

caption = "A giraffe surrounded by "
caption << "weezards!" # Me, too!
