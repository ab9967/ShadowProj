def hotel_cost(nights):
    return nights*140
    print nights*140
