from datetime import datetime
now = datetime.now()

current_year = now.year
current_month = now.month
current_day = now.day


print now.year
print now.month
print now.day
