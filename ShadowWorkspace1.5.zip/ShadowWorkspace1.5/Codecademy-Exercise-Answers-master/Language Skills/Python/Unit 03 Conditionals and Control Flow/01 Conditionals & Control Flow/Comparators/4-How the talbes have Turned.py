# Create comparative statements as appropriate on the lines below!

# Make me true!
bool_one = 3 < 5  # We already did this one for you!

# Make me false!
bool_two = 3>= 6

# Make me true!
bool_three = 2!= 3

# Make me false!
bool_four = 43 <=40

# Make me true!
bool_five = 90> 2
