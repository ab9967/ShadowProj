# Write your code below, starting on line 3!
my_string = 'admin'
print len(my_string)
print my_string.upper()
