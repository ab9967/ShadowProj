menu = {} # Empty dictionary
menu['Chicken Alfredo'] = 14.50 # Adding new key-value pair
print menu['Chicken Alfredo']

# Your code here: Add some dish-price pairs to menu!
menu['treta'] = 2.3
menu['treta2'] = 24.3
menu['treta3'] = 22.3


print "There are " + str(len(menu)) + " items on the menu."
print menu
