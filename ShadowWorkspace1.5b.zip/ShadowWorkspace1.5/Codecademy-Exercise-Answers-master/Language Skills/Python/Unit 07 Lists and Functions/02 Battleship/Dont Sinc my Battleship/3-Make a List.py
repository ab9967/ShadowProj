board = []

for loop in range(0, 5):
    treta = ["O"] * 5
    board.append(treta)
    print board
