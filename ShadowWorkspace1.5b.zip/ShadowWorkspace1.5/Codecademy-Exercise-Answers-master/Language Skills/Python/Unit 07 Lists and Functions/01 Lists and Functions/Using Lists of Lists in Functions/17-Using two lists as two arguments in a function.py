m = [1, 2, 3]
n = [4, 5, 6]
n = [3, 5, 7]
# Add your code here!
def join_lists(x, y):
    return x + y
print join_lists(m, n)
# You want this to print [1, 2, 3, 4, 5, 6]
