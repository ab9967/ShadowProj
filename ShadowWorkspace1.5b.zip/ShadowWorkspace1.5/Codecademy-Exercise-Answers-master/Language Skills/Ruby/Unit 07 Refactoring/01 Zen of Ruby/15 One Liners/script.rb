puts "One is less than two!" if 1 < 2
