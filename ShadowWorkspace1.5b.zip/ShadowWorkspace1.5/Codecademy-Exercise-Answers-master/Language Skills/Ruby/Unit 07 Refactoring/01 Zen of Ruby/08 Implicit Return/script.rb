def multiple_of_three(n)
  n % 3 == 0 ? "True" : "False"
end
