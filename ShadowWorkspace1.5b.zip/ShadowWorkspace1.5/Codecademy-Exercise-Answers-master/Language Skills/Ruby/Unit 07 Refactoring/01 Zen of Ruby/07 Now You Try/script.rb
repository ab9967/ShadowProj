# Write your code on line 2!
favorite_language ||= "Python"
puts favorite_language
