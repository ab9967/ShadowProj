age = 26
# Add your code below!
age.respond_to?(:next)
