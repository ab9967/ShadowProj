# Type your Ruby code below!
puts "Hi!" if true
