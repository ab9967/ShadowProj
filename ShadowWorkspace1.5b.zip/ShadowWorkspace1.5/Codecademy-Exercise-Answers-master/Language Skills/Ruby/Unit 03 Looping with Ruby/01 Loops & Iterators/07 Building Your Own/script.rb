for variable in 1..20
    puts variable
end