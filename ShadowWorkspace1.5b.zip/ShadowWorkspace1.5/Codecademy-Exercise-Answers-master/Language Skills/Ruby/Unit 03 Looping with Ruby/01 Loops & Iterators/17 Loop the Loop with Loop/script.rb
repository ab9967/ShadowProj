m= 0
loop do
    m += 1
    print "Ruby!"
    break if m == 30
end
