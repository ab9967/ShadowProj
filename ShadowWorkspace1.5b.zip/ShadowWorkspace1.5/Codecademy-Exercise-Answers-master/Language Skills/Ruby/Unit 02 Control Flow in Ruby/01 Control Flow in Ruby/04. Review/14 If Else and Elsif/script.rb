if 244<3
	puts "hello"
elsif 44<5
	puts "hobs"
else 
	puts
                  "sheets!"
end