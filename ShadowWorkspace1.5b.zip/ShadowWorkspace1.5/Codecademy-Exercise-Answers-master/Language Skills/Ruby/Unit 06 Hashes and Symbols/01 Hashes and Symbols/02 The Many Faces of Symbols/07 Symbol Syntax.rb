# Write your code below!
my_first_symbol = :anyvalidsymbol
