loop_condition = True

while loop_condition:
    print "I am a loop"
    loop_condition = False
