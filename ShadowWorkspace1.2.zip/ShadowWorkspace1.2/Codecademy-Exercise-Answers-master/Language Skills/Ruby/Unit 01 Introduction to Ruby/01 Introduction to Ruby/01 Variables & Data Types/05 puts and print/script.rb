puts "Double spaced"
print "A line"
