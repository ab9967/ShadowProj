fruits = ["orange", "apple", "banana", "pear", "grapes"]
fruits.sort! { |firstBook, secondBook| secondBook <=> firstBook }
